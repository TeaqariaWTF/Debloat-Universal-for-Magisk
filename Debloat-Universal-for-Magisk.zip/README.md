# Debloat Universal for Magisk

Elimina aplicaciones Android flasheando este modulo por magisk, eliminando aplicaciones que son poco utilizadas o basura de tu ROM basada en AOSP/MIUI y dejala más liviana y optimizada

_**Si desea usar este modulo o compartir no olvide dar los creditos correspondientes :)**_

Telegram: [*t.me/apmods*](https://t.me/apmods)

Autor: [*t.me/artistaproducer*](https://t.me/artistaproducer)

Cambios:

+ Ahora podrá actualizar desde Magisk en caso dado que salga una nueva actualiacion de la Version Debloat
+ Actualiado script que mejora la busqueda y eliminacion de aplicaciones

 
